/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.perpustakaan_naylalelyanggrahenihutomo_061;

/**
 *
 * @author nitro
 */
public class Buku {
    private String judul;
    private String pengarang;
    private int tahunTerbit;
    private String isbn;
    private int jumlahStok;
    
    public Buku(String judul, String pengarang, int tahunTerbit, String isbn, int jumlahStok) {
        this.judul = judul;
        this.pengarang = pengarang;
        this.tahunTerbit = tahunTerbit;
        this.isbn = isbn;
        this.jumlahStok = jumlahStok;
    }

    // Getter & Setter
    public String getJudul() { return judul; }
    public void setJudul(String judul) { this.judul = judul; }

    public String getPengarang() { return pengarang; }
    public void setPengarang(String pengarang) { this.pengarang = pengarang; }

    public int getTahunTerbit() { return tahunTerbit; }
    public void setTahunTerbit(int tahunTerbit) { this.tahunTerbit = tahunTerbit; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public int getJumlahStok() { return jumlahStok; }
    public void setJumlahStok(int jumlahStok) { this.jumlahStok = jumlahStok; }
    
    public String toString() {
        return "Judul: " + judul + "\n" +
               "Pengarang: " + pengarang + "\n" +
               "Tahun Terbit: " + tahunTerbit + "\n" +
               "ISBN: " + isbn + "\n" +
               "Jumlah Stok: " + jumlahStok + "\n"; 
    }
}
