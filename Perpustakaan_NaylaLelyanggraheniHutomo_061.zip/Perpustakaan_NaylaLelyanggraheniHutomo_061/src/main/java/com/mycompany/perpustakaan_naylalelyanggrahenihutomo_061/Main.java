/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.perpustakaan_naylalelyanggrahenihutomo_061;

/**
 *
 * @author nitro
 */
public class Main {
    public static void main(String[] args) {
        Perpustakaan perpus = new Perpustakaan();
        
        Buku b1 = new Buku("Jejak Langkah Digital", "Andi Prasetyo", 2021, "978-602-1234-11-0", 15);
        Buku b2 = new Buku("Bisnis Kreatif di Era Digital", "Michael Gunawan", 2023, "978-623-8888-90-1", 10);
        
        perpus.tambahBuku(b1);
        perpus.tambahBuku(b2);
        
        System.out.println("== Perpustakaan Sederhana ==");
        perpus.tampilkanBuku();
        
        perpus.updateStok(0, 12); 
        perpus.updateStok(1, 8);  
        
        System.out.println("Setelah update stok");
        System.out.println("== Perpustakaan Sederhana ==");
        perpus.tampilkanBuku();
    }
}
