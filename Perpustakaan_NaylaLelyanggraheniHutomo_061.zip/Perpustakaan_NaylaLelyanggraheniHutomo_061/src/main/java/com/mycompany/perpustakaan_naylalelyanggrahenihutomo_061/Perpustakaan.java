/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.perpustakaan_naylalelyanggrahenihutomo_061;

/**
 *
 * @author nitro
 */
import java.util.ArrayList;

public class Perpustakaan {
    private ArrayList<Buku> daftarBuku = new ArrayList<>();

    public void tambahBuku(Buku b) {
        daftarBuku.add(b);
    }

    public void tampilkanBuku() {
        for (int i = 0; i < daftarBuku.size(); i++) {
            System.out.println((i+1) + ". " + daftarBuku.get(i));
        }
    }

    public void updateStok(int index, int stokBaru) {
        if (index >= 0 && index < daftarBuku.size()) {
            daftarBuku.get(index).setJumlahStok(stokBaru);
        } else {
            System.out.println("Index tidak valid!");
        }
    }
}


